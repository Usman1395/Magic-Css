
// Chrome native search + reliable focus/selection restore + auto CSS sync + Ctrl+S push
(function(){
  function getEditor(){
    try{ if(window.editor && typeof window.editor.getSelection==='function') return window.editor; }catch(e){}
    try{ const el=document.querySelector('.CodeMirror'); if(el && el.CodeMirror) return el.CodeMirror; }catch(e){}
    return null;
  }
  function getCurrentCSS(){
    try{ if (window.editor && typeof window.editor.getValue==='function') return window.editor.getValue(); }catch(e){}
    try{ const el=document.querySelector('.CodeMirror'); if(el && el.CodeMirror) return el.CodeMirror.getValue(); }catch(e){}
    try{ const ta=document.querySelector('textarea'); if(ta) return ta.value; }catch(e){}
    return '';
  }
  function pushCSS(){
    const css=getCurrentCSS();
    try{ chrome.runtime.sendMessage({ type:'CTRL_S_PUSH_CSS', css }); }catch(err){}
  }

  let cm=null, lastSelections=null, lastScroll=null;
  function bindCM(){
    cm = getEditor();
    if(!cm) return false;
    try{
      cm.on && cm.on('cursorActivity', function(){
        try{
          if(cm.listSelections) lastSelections = cm.listSelections();
          if(cm.getScrollInfo) lastScroll = cm.getScrollInfo();
        }catch(e){}
      });
    }catch(e){}
    // capture an initial snapshot
    try{
      if(cm.listSelections) lastSelections = cm.listSelections();
      if(cm.getScrollInfo) lastScroll = cm.getScrollInfo();
    }catch(e){}
    return true;
  }
  // wait until CodeMirror is available
  const wait = setInterval(function(){
    if(bindCM()){ clearInterval(wait); }
  }, 200);

  function restoreFocusAndSelection(retries){
    let attempts = 0;
    const id = setInterval(function(){
      attempts++;
      const ed = cm || getEditor();
      if(ed){
        try{
          ed.focus && ed.focus();
          if(lastSelections && ed.setSelections){
            ed.setSelections(lastSelections);
          }else if(ed.setSelection && ed.getCursor){
            ed.setSelection(ed.getCursor(true), ed.getCursor(false));
          }
          if(lastScroll && ed.scrollTo){
            ed.scrollTo(lastScroll.left, lastScroll.top);
          }
        }catch(e){}
      }
      if(attempts >= (retries||15)) clearInterval(id);
    }, 50);
  }

  // --- Manual push on Ctrl+S ---
  window.addEventListener('keydown', function(e){
    if((e.ctrlKey || e.metaKey) && String(e.key).toLowerCase()==='s'){
      e.preventDefault();
      pushCSS();
    }
  }, true);

  // --- Auto CSS sync on typing (debounced) ---
  let timer=null;
  window.addEventListener('keyup', function(e){
    // don't trigger on modifier-only keys
    if(e.key && ['Shift','Control','Meta','Alt','CapsLock'].includes(e.key)) return;
    clearTimeout(timer);
    timer=setTimeout(pushCSS, 300);
  }, true);

  // --- Chrome native find integration ---
  function onFindHotkey(){
    // snapshot current selection/scroll before Chrome's Find opens
    const ed = cm || getEditor();
    if(ed){
      try{
        if(ed.listSelections) lastSelections = ed.listSelections();
        if(ed.getScrollInfo) lastScroll = ed.getScrollInfo();
      }catch(e){}
    }
    // after the find UI interacts, restore focus/selection repeatedly
    setTimeout(function(){ restoreFocusAndSelection(20); }, 50);
  }

  window.addEventListener('keydown', function(e){
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='f'){
      // Let Chrome handle native find; we only assist
      onFindHotkey();
    }
    if((e.ctrlKey||e.metaKey) && e.shiftKey && e.key.toLowerCase()==='f'){
      onFindHotkey();
    }
    if(e.key === 'Escape'){
      // user likely closed the find bar; refocus and restore selection
      setTimeout(function(){ restoreFocusAndSelection(20); }, 50);
    }
  }, true);
})();
