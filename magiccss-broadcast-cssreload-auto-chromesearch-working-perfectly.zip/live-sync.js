// live-sync.js
(function() {
  const host = location.hostname || "unknown-host";
  const KEY = `magiccss_live_css:${host}`;
  const STYLE_ID = "magiccss-live-sync-style";

  function ensureStyleEl() {
    let el = document.getElementById(STYLE_ID);
    if (!el) {
      el = document.createElement("style");
      el.id = STYLE_ID;
      document.documentElement.appendChild(el);
    }
    return el;
  }

  // Apply current css if exists
  chrome.storage.local.get([KEY], (res) => {
    if (res && res[KEY]) {
      ensureStyleEl().textContent = res[KEY];
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[KEY]) return;
    ensureStyleEl().textContent = changes[KEY].newValue || "";
  });

  window.addEventListener("message", (ev) => {
    if (ev.data && ev.data.source === "magiccss-editor" && ev.data.type === "apply-css") {
      ensureStyleEl().textContent = ev.data.css || "";
      const obj = {}; obj[KEY] = ev.data.css || "";
      chrome.storage.local.set(obj);
    }
  });
})();

// ctrl+s apply-css handler (broadcast)
try{
chrome.runtime.onMessage.addListener((msg)=>{
  if(msg && msg.type==='APPLY_CSS_TEXT'){
    let el=document.getElementById('magiccss-ctrls-style');
    if(!el){ el=document.createElement('style'); el.id='magiccss-ctrls-style'; document.documentElement.appendChild(el); }
    el.textContent = msg.css || '';
  }
});
}catch(e){}
