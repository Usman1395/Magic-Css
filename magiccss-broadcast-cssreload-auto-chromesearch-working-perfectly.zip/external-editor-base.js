import { myWin } from './scripts/appUtils/myWin.js';

(function () {
    try {
        const
            urlParams = new URLSearchParams(window.location.search),
            tabTitle = urlParams.get('tabTitle');
        if (tabTitle) {
            document.title = 'Magic CSS: ' + tabTitle;
        } else {
            document.title = 'Magic CSS';
        }
    } catch (e) {
        // do nothing
    }

    // Force editor to open in external window
    myWin.flagEditorInExternalWindow = true;
    myWin.treatAsNormalWebpage = true;
    
    // Additional logic to ensure external opening
    if (!myWin.isExternalWindow) {
        myWin.openInExternalWindow();
    }
    
    // Prevent any internal window opening attempts
    const originalOpenInTab = myWin.openInTab;
    myWin.openInTab = function() {
        console.log("Redirecting to external window...");
        return myWin.openInExternalWindow.apply(this, arguments);
    };
})();

// --- Custom modifications injected ---

// Always open external editor handled via manifest change.

// Domain-wide CSS persistence
(function() {
  function getDomain() {
    return window.location.hostname.replace(/^www\./, '');
  }
  const domain = getDomain();
  const storageKey = "magiccss_domain_" + domain;

  // Load stored CSS on init
  chrome.storage.local.get(storageKey, function(data) {
    if (data && data[storageKey]) {
      try {
        document.querySelector('#magicss-editor').value = data[storageKey];
      } catch(e) {}
    }
  });

  // Save CSS on change
  document.addEventListener('input', function(e) {
    if (e.target && e.target.id === 'magicss-editor') {
      let css = e.target.value;
      let obj = {};
      obj[storageKey] = css;
      chrome.storage.local.set(obj);
    }
  });
})();

// Search functionality inside external editor
(function() {
  let editor = document.querySelector('#magicss-editor');
  if (!editor) return;

  // Create search box UI
  let searchBox = document.createElement('input');
  searchBox.type = 'text';
  searchBox.placeholder = 'Search CSS...';
  searchBox.style.position = 'absolute';
  searchBox.style.top = '5px';
  searchBox.style.right = '5px';
  searchBox.style.zIndex = '9999';
  searchBox.style.padding = '2px';
  searchBox.style.fontSize = '12px';
  document.body.appendChild(searchBox);

  let lastPos = 0;
  searchBox.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      let text = searchBox.value;
      if (!text) return;
      let content = editor.value;
      let idx = content.indexOf(text, lastPos + 1);
      if (idx === -1) {
        idx = content.indexOf(text, 0);
      }
      if (idx !== -1) {
        editor.focus();
        editor.setSelectionRange(idx, idx + text.length);
        lastPos = idx;
      }
    }
    if (e.key === 'Escape') {
      searchBox.value = '';
      editor.focus(); // Refocus back on editor instead of losing cursor
    }
  });

  // Prevent ESC from closing extension
  window.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
    }
  }, true);
})();


// --- Second round of modifications ---

// Instant apply CSS across tabs of same domain without reload
(function() {
  function getDomain() {
    return window.location.hostname.replace(/^www\./, '');
  }
  const domain = getDomain();
  const storageKey = "magiccss_domain_" + domain;

  let editor = document.querySelector('#magicss-editor');
  if (!editor) return;

  function broadcastCss(css) {
    chrome.tabs.query({}, function(tabs) {
      tabs.forEach(tab => {
        try {
          let url = new URL(tab.url);
          let tabDomain = url.hostname.replace(/^www\./, '');
          if (tabDomain === domain) {
            chrome.scripting.insertCSS({
              target: { tabId: tab.id },
              css: css
            }).catch(()=>{});
          }
        } catch(e) {}
      });
    });
  }

  // Broadcast on change
  editor.addEventListener('input', function() {
    let css = editor.value;
    let obj = {};
    obj[storageKey] = css;
    chrome.storage.local.set(obj);
    broadcastCss(css);
  });

  // Apply instantly when switching tab back
  chrome.tabs.onActivated.addListener(function(activeInfo) {
    chrome.tabs.get(activeInfo.tabId, function(tab) {
      if (tab && tab.url) {
        let url = new URL(tab.url);
        if (url.hostname.replace(/^www\./, '') === domain) {
          chrome.storage.local.get(storageKey, function(data) {
            if (data && data[storageKey]) {
              broadcastCss(data[storageKey]);
            }
          });
        }
      }
    });
  });
})();

// Enhanced search escape handling
(function() {
  let editor = document.querySelector('#magicss-editor');
  if (!editor) return;

  let searchBox = document.querySelector('input[placeholder="Search CSS..."]');
  if (!searchBox) return;

  let lastSelection = null;

  searchBox.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      let text = searchBox.value;
      if (!text) return;
      let content = editor.value;
      let idx = content.indexOf(text, editor.selectionEnd);
      if (idx === -1) {
        idx = content.indexOf(text, 0);
      }
      if (idx !== -1) {
        editor.focus();
        editor.setSelectionRange(idx, idx + text.length);
        lastSelection = {start: idx, end: idx + text.length};
      }
    }
    if (e.key === 'Escape') {
      searchBox.value = '';
      if (lastSelection) {
        editor.focus();
        editor.setSelectionRange(lastSelection.start, lastSelection.end);
      } else {
        editor.focus();
      }
    }
  });
})();
