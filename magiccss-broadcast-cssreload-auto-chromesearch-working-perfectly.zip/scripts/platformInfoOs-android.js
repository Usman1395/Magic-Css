window.platformInfoOs = 'android';
