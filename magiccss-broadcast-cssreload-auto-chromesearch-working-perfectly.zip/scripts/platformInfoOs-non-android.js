window.platformInfoOs = 'non-android';
